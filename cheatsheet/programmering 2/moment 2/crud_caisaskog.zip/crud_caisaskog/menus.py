mainMenuAlt = '''
Välkommen till Speculative Fiction
En app för du som vill samla ditt film och serie tittande lättare!

Vad vill du göra?
1. Logga in 
2. Skapa konto
3. Avsluta program
'''

loggedInMenuAlt = '''
Välkommen {0}!

Vad vill du göra?
1. Gå till lista
2. Ändra användare
3. Logga ut
4. Avsluta program
'''

accountSettingsAlt = '''
Ändra konto

1. Ändra användarnamn
2. Ändra lösenord
3. Ta bort konto
4. Gå tillbaka
'''

fictionMenuAlt = '''
Välkommen till din fiktion lista!

Vad vill du göra?

1. Visa lista
2. Lägg in ny fiktion
3. Gå tillbaka
'''

fictionViewAlt = '''
Visar {0}

Vad vill du göra?
1. Ändra status
2. Lägga till/ändra kommentar
3. Lägga till/ändra rating
4. Ta bort {1}
5. Gå tillbaka
'''